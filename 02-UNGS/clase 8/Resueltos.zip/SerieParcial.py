n=int(input("Ingrese la cantidad de terminos que desea"))
signo=1
suma=2
for i in range(1,n-1):
    suma=suma+(i+2)/(2**(2*i))*signo
    signo= signo * (-1)
print(suma)