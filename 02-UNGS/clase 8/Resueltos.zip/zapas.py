precioRojo=float(input("Ingrese el precio de la marca Rojo"))
precioBlanco=float(input("Ingrese el precio de la marca Blanco"))

if precioRojo < precioBlanco:
     precio=precioRojo
     marca="Rojo"
else:
    precio=precioBlanco
    marca="Blanco"

todoEfectivo=precio * (1 - 0.15)
tarjetaGold=precio*(1 - 0.15)
tarjetaBlack=precio *( 1 - 0.016 * 3 - 0.1)

if precio < 1000:
    print("Paga en efectivo $",todoEfectivo)
else:
    if tarjetaGold <= todoEfectivo and tarjetaGold <= tarjetaBlack:
         print("Paga con la tarjeta Gold $",tarjetaGold)
    else:
        if tarjetaBlack <= todoEfectivo and tarjetaBlack <= tarjetaBlack:
            print("Paga con la tarjeta Black $",tarjetaBlack)
        else:
            print("Paga en efectivo $",todoEfectivo)

print("Compra las zapatilla marca ", marca)
