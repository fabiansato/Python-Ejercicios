import random

n=int(input("Cuantas patentes quieres: (0-50) "))
letras="abcdefghijklmnopqrstuvwxyz"
cont=0
patente="p"
azar1= random.randrange(len(letras))
azar2= random.randrange(len(letras))

for letra in letras:
    if cont == azar1 or cont == azar2:
        patente=patente+letra
    cont = cont + 1
numero=""

num=random.randrange(1000)

while (num+n>999):
    num=random.randrange(1000)

numero=numero+str(num)

for i in range(n):
    print (patente + str(numero))
    numero = int (numero) + 1



##for i in range(n):
##    if int(numero)<10:
##            print (patente +"00"+ str(numero))
##    elif int(numero)<100:
##        print (patente +"0"+ str(numero))
##    else:
##        print (patente + str(numero))
##    numero = int (numero) + 1

