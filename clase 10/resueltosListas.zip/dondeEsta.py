def dondeEsta(cadena,letra):
    for i in range(len(cadena)):
        if cadena[i]==letra:
            return i
    return -1


def dondeEstan(cadena,letra):
    nueva=[]
    for i in range(len(cadena)):
        if cadena[i]==letra:
            nueva.append(i)
    return nueva





