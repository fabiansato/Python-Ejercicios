def alReves(lista):
    nueva=[]
    for i in range(len(lista)-1,-1,-1):
        nueva.append(lista[i])
    return nueva

a=[1,2,3,4,5,6,9]
print(alReves(a))
