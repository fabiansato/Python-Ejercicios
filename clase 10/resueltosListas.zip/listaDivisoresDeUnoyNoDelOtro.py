def listaDivisoresDeUnoYnoDelOtro(a,b):
    lista=[]
    for i in range(1,a+1):
        if(a%i==0 and b%i!=0):
            lista.append(i)
    return lista