def cantApariciones(cadena,letra):
    cant=0
    for i in range(len(cadena)):
        if cadena[i]==letra:
            cant+=1
    return cant