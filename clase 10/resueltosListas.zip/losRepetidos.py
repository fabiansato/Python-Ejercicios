def cantApariciones(cadena,letra):
    cant=0
    for i in range(len(cadena)):
        if cadena[i]==letra:
            cant+=1
    return cant

def esta(letra,cadena):
    return(cantApariciones(cadena,letra)>=1)

def losRepetidos(cadena):
    lista=[]
    for i in range(len(cadena)):
        if(cantApariciones(cadena,cadena[i])>1 and not esta(cadena[i],lista)):
            lista.append(cadena[i])
    return lista


print(losRepetidos("conocido"))

