def cantApariciones(cadena,letra):
    cant=0
    for i in range(len(cadena)):
        if cadena[i]==letra:
            cant+=1
    return cant


def tieneRepetidos(cadena):
    bandera=False
    for i in range(len(cadena)):
        if(cantApariciones(cadena,cadena[i])>1):
            bandera=True
    return bandera





