def esPrimo(n):
    cant=0
    for i in range(1,n+1):
        if (n%i==0):
            cant+=1
    if(cant==2):
        return True
    else:
        return False

def esPrimo2(n):
    for i in range(2,n//2+1):
        if(n%i==0):
            return False
    return True



def losPrimos(n):
    lista=[]
    for i in range(1,n+1):
        if (esPrimo(i)):
            lista.append(i)
    return lista

print(losPrimos(1000))


