def puntaje(d,p):
    Deno = [2,3,4,5,6,7,8,9,10,'j','q','k','a']
    valorDeno = [2,3,4,5,6,7,8,9,10,11 ,12 , 13, 14]
    palo = ['D','P','C','T'] #Diamante, Pica, Corazón, Trébol
    valorPalo = [80 ,70 ,60 , 50]
    punto=0
    for i in range(len(Deno)):
        if Deno[i]==d:
            punto+=valorDeno[i]
    for i in range(len(palo)):
        if palo[i]==p:
            punto+=valorPalo[i]
    return punto

def mayor(a,b,c):
    if a> b and a>c:
        return a
    elif b>a and b>c:
        return b
    else:
        return c

Deno = [2,3,4,5,6,7,8,9,10,'j','q','k','a']
valorDeno = [2,3,4,5,6,7,8,9,10,11 ,12 , 13, 14]
palo = ['D','P','C','T'] #Diamante, Pica, Corazón, Trébol
valorPalo = [80 ,70 ,60 , 50]

J1_deno = [ 2 , 10,'a','q']
J1_palo = ['T','C','D','D']
J2_palo= ['T','C','D','C']
J2_deno= ['a', 8 , 2 ,'a']
J3_deno= [ 7 ,'a','k',10 ]
J3_palo= ['T','P','D','D']

for i in range(len(J1_deno)):
    j1=puntaje(J1_deno[i],J1_palo[i])
    print("jugador1:",j1)
    j2=puntaje(J2_deno[i],J2_palo[i])
    print("jugador2:",j2)
    j3=puntaje(J3_deno[i],J3_palo[i])
    print("jugador3:",j3)
    m=mayor(j1,j2,j3)
    print("Pierde el que obtuvo:", m)