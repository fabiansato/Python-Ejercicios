def esPrimo(n):
    for i in range(2,n):
        if n%i==0:
            return False
    return True

def listaDivPrimos(n):
    lista=[]
    for i in range(1,n+1):
        if n%i==0 and esPrimo(i):
            lista.append(i)
    return lista

def distanciaMax(n):
    lista=listaDivPrimos(n)
    max=0
    for i in range(len(lista)-1):
        if lista[i+1]-lista[i]>max:
            max=lista[i+1]-lista[i]
    return max

n=66
print(distanciaMax(n))




