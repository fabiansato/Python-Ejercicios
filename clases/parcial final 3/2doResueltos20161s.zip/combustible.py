#relojArranque() retorna los segundos transcurridos desde que el auto se puso en marcha.
#combustibleTanque() retorna el volumen de combustible en el tanque en litros.
#velocidadAuto() retorna la velocidad a la que viaja el auto en Km por hora.
#consumoPorVelocidad(velocidad) dada la velocidad retorna el consumo en litros por Km.
#autonomiaAuto(consumo,combustible) para el ritmo de consumo y el combustible que le queda retorna la distancia que puede recorrer en Km.
#alertarConductor() envía un alerta cuando le quedan menos de 50 Km

while(True):
    if (relojArranque()%60==0):
        combustible= combustibleTanque()
        velocidad= velocidad= ()
        consumo= consumoPorVelocidad(velocidad)
        autonomia= autonomiaAuto(consumo,combustible)
        if autonomia<50:
            alertarConductor()
