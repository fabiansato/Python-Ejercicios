def esta(elemento,cadena):
    for elem in cadena:
        if elem==elemento:
            return True
    return False


def puntaje(cadena):
    vocalesMin=["a","e","i","o","u"]
    vocalesMay=["A","E","I","O","U"]
    consonantesDif=["q","k","x","y","z","Q","K","X","Y","Z"]

    puntos=0
    for letra in cadena:
        if esta(letra, vocalesMin):
            puntos+=1
        elif(esta(letra,vocalesMay)):
            puntos+=2
        elif(esta(letra,consonantesDif)):
            puntos+=10
        else:
            puntos+=4
    return puntos

cadena="Axioma"
print(puntaje(cadena))


