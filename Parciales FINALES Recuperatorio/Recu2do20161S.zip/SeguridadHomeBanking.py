import random
def esta(elemento, lista):
    for ele in lista:
        if ele == elemento:
            return True
    return False

def dondeEsta(elemento, lista):
    for i in range(len(lista)):
        if elemento==lista[i]:
            return i
    return -1

listaUsuarios=["pepito16","papasFritas","clave2016"]
listaClaves=["20160430","Ruta8y202","aBc123"]
listaDNI=[32451671,38007376,36961155]

usuario=input("Ingrese su usuario")
clave=input("Ingrese su clave")

if esta(usuario,listaUsuarios) and esta(clave,listaClaves):
    lista=[]
    for i in range(6):
        aleatorio=random.randrange(100,999)
        lista.append(aleatorio)
    dniCompleto=str(listaDNI[dondeEsta(usuario,listaUsuarios)])
    ultimos3=dniCompleto[len(dniCompleto)-3]+dniCompleto[len(dniCompleto)-2]+dniCompleto[len(dniCompleto)-1]
    indice=random.randrange(6)
    lista[indice]=int(ultimos3)
    print(lista)
else:
    print("Error Usuario y/o clave")




