##paraisosFiscales( ): devuelve una lista de países donde se crean cuentas para lavado de dinero.
##posiblesEvasores( ): Devuelve una lista de los dni de personas que se quiere controlar.
##control(DNI, paises ): Recibe un dni y una lista de países y devuelve True si esa persona tiene cuenta en alguno de esos países, False en caso contrario.
##enviar( lista ) : envía la lista a la oficina anticorrupción para que pueda citar a los evasores.


listaPaises=paraisosFiscales()
listaPosiblesEvasores=posiblesEvasores()
listaEvasores=[]
for dni in listaPosiblesEvasores:
    if control(dni, listaPaises):
        listaEvasores.append(dni)
enviar(listaEvasores)
