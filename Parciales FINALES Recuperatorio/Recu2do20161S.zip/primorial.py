def cantDivisores(n):
    cant=0
    for i in range(1,n+1):
        if n%i==0:
            cant+=1
    return cant

def esPrimo(n):
    if cantDivisores(n)==2:
        return True
    else:
        return False

def primorial(n):
    producto=1
    i=2
    while(producto<n):
        if esPrimo(i):
            producto=producto*i
        i=i+1
    if producto==n:
        return True
    else:
        return False


n=15
print(primorial(n))

