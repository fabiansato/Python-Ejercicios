def esta(elemento, lista):
    for ele in lista:
        if ele == elemento:
            return True
    return False

tipos = ["A", "B", "J", "M", "F"]
clases = [8, 156, 31, 4, 25, 601, 10]
recibidos = ["L31", "B8", "B15", "A8", "Z25", "P156", "P31"]

for codigo in recibidos:
    if not esta(codigo[0],tipos):
        tipos.append(codigo[0])
    nuevo=""
    for i in range(1,len(codigo)):
        nuevo=nuevo+str(codigo[i])
    if not esta(int(nuevo),clases):
        clases.append(int(nuevo))
print(tipos)
print(clases)




